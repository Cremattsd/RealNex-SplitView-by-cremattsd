// Matty’s Blackout – v9.5 (True Dual Mode + Toolkit Bridge)
// Works with Matty’s Toolkit v14 popup and content bridge.
// Light mode untouched perfection; Dark mode flips icons + text to full white.

const ORANGE_SHADES = [
  '#f7931e','#ee7600','#f58025','#ff8800','#f57c00','#f45000','#f15929'
];
const ACTIVE_ICON_COLOR = '#333333';
let darkMode = false;

// 🔌 Listen for runtime messages (direct from popup)
chrome.runtime.onMessage.addListener(req => {
  if (req.action === 'darkMode' || req.action === 'lightMode' || req.action === 'resetMode') {
    darkMode = req.action === 'darkMode' ? req.state : false;
    chrome.storage.local.set({ darkMode });
    replaceAllColors();
  }
});

// 🔌 Also listen to window messages (from content bridge)
window.addEventListener("message", (event) => {
  const { action, state } = event.data || {};
  if (!action) return;

  if (action === 'darkMode') {
    darkMode = state;
    chrome.storage.local.set({ darkMode });
    console.log("🌙 Blackout → Dark Mode triggered via bridge");
    replaceAllColors();
  } else if (action === 'lightMode') {
    darkMode = false;
    chrome.storage.local.set({ darkMode: false });
    console.log("☀️ Blackout → Light Mode triggered via bridge");
    replaceAllColors();
  } else if (action === 'resetMode') {
    darkMode = false;
    chrome.storage.local.set({ darkMode: false });
    console.log("🔄 Blackout reset to default");
    replaceAllColors();
  }
});

// Auto-update if DOM changes (handles RealNex reloads)
const observer = new MutationObserver(replaceAllColors);
observer.observe(document.body, { childList: true, subtree: true });

function replaceAllColors() {
  const linkColor = darkMode ? '#ffffff' : '#333333';
  const textColor = darkMode ? '#ffffff' : '#333333';
  const bgColor = darkMode ? '#0f0f0f' : '#ffffff';

  document.body.style.transition = 'background-color .3s ease, color .3s ease';
  document.body.style.backgroundColor = bgColor;
  document.body.style.color = textColor;

  document.querySelectorAll('*').forEach(el => {
    const style = window.getComputedStyle(el);
    const bg = style.backgroundColor?.toLowerCase?.() || '';
    const color = style.color?.toLowerCase?.() || '';
    const border = style.borderColor?.toLowerCase?.() || '';

    // --- 1. Orange cleanup
    ORANGE_SHADES.forEach(hex => {
      const rgb = hexToRgb(hex);
      const match =
        bg.includes(hex.slice(1)) || bg.includes(rgb) ||
        color.includes(hex.slice(1)) || color.includes(rgb) ||
        border.includes(hex.slice(1)) || border.includes(rgb);

      if (match) {
        el.style.setProperty('background-color', darkMode ? '#111111' : '#ffffff', 'important');
        el.style.setProperty('color', darkMode ? '#ffffff' : '#333333', 'important');
        el.style.setProperty('border-color', darkMode ? '#888888' : '#000000', 'important');
      }
    });

    // --- 2. Gray text flip (#333 / #2f2f2f)
    if (
      color.includes('#333333') || color.includes('51, 51, 51') ||
      color.includes('#2f2f2f') || color.includes('47, 47, 47')
    ) {
      el.style.setProperty('color', darkMode ? '#ffffff' : '#333333', 'important');
    }

    // --- 3. White text invert in light mode
    if (color.includes('#ffffff') || color.includes('255, 255, 255')) {
      el.style.setProperty('color', darkMode ? '#ffffff' : '#333333', 'important');
    }

    // --- 4. Buttons
    if (el.classList && (
      el.classList.contains('btn-primary') ||
      el.classList.contains('btn-warning') ||
      el.classList.contains('btn-secondary') ||
      el.classList.contains('btn-edit') ||
      el.classList.contains('btn-verify') ||
      el.classList.contains('proceed-btn')
    )) {
      el.style.setProperty('background-color', darkMode ? '#222' : '#ffffff', 'important');
      el.style.setProperty('color', darkMode ? '#ffffff' : '#333333', 'important');
      el.style.setProperty('border', darkMode ? '1px solid #555' : '1px solid #000', 'important');
      el.style.setProperty('border-radius', '6px', 'important');
      el.style.setProperty('transition', 'all .25s ease', 'important');
    }

    // --- 5. Headers / modals
    if (el.classList && el.classList.contains('modal-header')) {
      el.style.setProperty('background-color', darkMode ? '#1a1a1a' : '#ffffff', 'important');
      el.style.setProperty('color', darkMode ? '#ffffff' : '#333333', 'important');
      el.style.setProperty('border-bottom', darkMode ? '1px solid rgba(255,255,255,0.1)' : '1px solid #000', 'important');

      const title = el.querySelector('.modal-title');
      if (title) title.style.setProperty('color', darkMode ? '#ffffff' : '#333333', 'important');

      const innerIcons = el.querySelectorAll('.material-symbols-rounded, .icon, i, span');
      innerIcons.forEach(ic => {
        ic.style.setProperty('color', darkMode ? '#ffffff' : '#333333', 'important');
      });
    }

    // --- 6. Icons
    if (el.classList && (
      el.classList.contains('material-symbols-rounded') ||
      el.classList.contains('icon') ||
      el.tagName === 'I' || el.tagName === 'SVG'
    )) {
      el.style.setProperty('color', darkMode ? '#ffffff' : ACTIVE_ICON_COLOR, 'important');
      el.style.setProperty('fill', darkMode ? '#ffffff' : ACTIVE_ICON_COLOR, 'important');
    }

    // --- 7. Address lines / labels / spans
    if (el.classList.contains('address-line') || el.tagName === 'SPAN' || el.tagName === 'LABEL') {
      el.style.setProperty('color', darkMode ? '#ffffff' : '#333333', 'important');
    }

    // --- 8. Links
    if (el.tagName === 'A') {
      el.style.setProperty('color', linkColor, 'important');
      el.style.setProperty('text-decoration', 'none', 'important');
    }
  });

  // --- 9. Cards + avatars
  document.querySelectorAll('.swiper-slide.bg-img').forEach(el => {
    el.style.setProperty('border-radius', '12px', 'important');
    el.style.setProperty('overflow', 'hidden', 'important');
  });

  document.querySelectorAll('img.avatar').forEach(img => {
    img.style.setProperty('border-radius', '10px', 'important');
    img.style.setProperty('object-fit', 'cover', 'important');
  });
}

// Helper
function hexToRgb(hex) {
  const bigint = parseInt(hex.slice(1), 16);
  const r = (bigint >> 16) & 255;
  const g = (bigint >> 8) & 255;
  const b = bigint & 255;
  return `rgb(${r},${g},${b})`;
}
