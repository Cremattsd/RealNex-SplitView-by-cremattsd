// Matty’s Toolkit Content Bridge — v14.0
console.log("🧩 Matty’s Toolkit content script loaded");

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log("📨 Toolkit message received:", msg);

  const { action, state } = msg || {};

  try {
    // 🌓 Forward theme messages to blackout.js (for color handling)
    if (["darkMode", "lightMode", "resetMode"].includes(action)) {
      window.postMessage({ action, state }, "*");
      console.log(`🎨 Forwarded ${action} to blackout.js`);
    }

    // 🪟 Handle Split View toggles and contact/property direction
    if (["splitViewToggle", "contactToPropertyToggle", "propertyToContactToggle"].includes(action)) {
      console.log(`🪟 Split toggle action triggered: ${action}`);
      chrome.runtime.sendMessage({ action, state }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn("⚠️ Split message routing failed:", chrome.runtime.lastError.message);
        } else {
          console.log("✅ Split message relayed to background:", response);
        }
      });
    }

    sendResponse({ received: true });
  } catch (err) {
    console.error("❌ Toolkit content bridge error:", err);
    sendResponse({ error: err.message });
  }
});
