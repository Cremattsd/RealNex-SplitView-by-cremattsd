// Matty’s Toolkit Background – v14 (Split View + Auto-Injection + Safe Messaging)
chrome.runtime.onInstalled.addListener(() => {
  console.log("✅ Matty’s Toolkit background loaded");
});

let splitWindows = { left: null, right: null };

// 🔹 Global message listener
chrome.runtime.onMessage.addListener(async (msg, sender, sendResponse) => {
  try {
    // --- Dynamic script injection ---
    if (msg.action === "executeScript" && msg.file) {
      if (!sender.tab?.id) return sendResponse({ status: "no_tab" });
      await chrome.scripting.executeScript({
        target: { tabId: sender.tab.id },
        files: [msg.file]
      });
      console.log(`⚡ Executed ${msg.file} on tab ${sender.tab.id}`);
      return sendResponse({ status: "executed", file: msg.file });
    }

    // --- Split View controls ---
    if (msg.action === "splitViewToggle" && msg.state) activateSplitView();
    if (msg.action === "contactToProperty") openSplitPair("contact", "property");
    if (msg.action === "propertyToContact") openSplitPair("property", "contact");

    // --- Theme persistence + injection ---
    if (["darkMode", "lightMode", "resetMode"].includes(msg.action)) {
      await chrome.storage.local.set({ [msg.action]: msg.state });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && !tab.url.startsWith("chrome://")) {
        await ensureContentScript(tab.id);
        chrome.tabs.sendMessage(tab.id, msg, () => {});
      }
    }

    sendResponse({ status: "ok" });
  } catch (err) {
    console.error("Toolkit background error:", err);
    sendResponse({ status: "error", message: err.message });
  }
});

// --- Split View Logic ---
async function activateSplitView() {
  const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!currentTab) return;

  const url = currentTab.url || "";
  const isContact = url.includes("/Contact#");
  const isProperty = url.includes("/property#");

  if (isContact) openSplitPair("contact", "property");
  else if (isProperty) openSplitPair("property", "contact");
  else console.log("Split mode not supported for this URL");
}

async function openSplitPair(primary, secondary) {
  const contactURL = "https://crm.realnex.com/Contact#";
  const propertyURL = "https://crm.realnex.com/property#";

  // Try reusing existing split windows first
  try {
    if (splitWindows.left?.id && splitWindows.right?.id) {
      const leftWin = await chrome.windows.get(splitWindows.left.id, { populate: true });
      const rightWin = await chrome.windows.get(splitWindows.right.id, { populate: true });

      if (leftWin && rightWin) {
        const leftTab = leftWin.tabs[0];
        const rightTab = rightWin.tabs[0];

        await chrome.tabs.update(leftTab.id, {
          url: primary === "contact" ? contactURL : propertyURL
        });
        await chrome.tabs.update(rightTab.id, {
          url: secondary === "property" ? propertyURL : contactURL
        });

        await chrome.windows.update(leftWin.id, { focused: true });
        console.log("♻️ Reused existing split windows");
        return;
      }
    }
  } catch (err) {
    console.warn("Could not reuse existing split windows:", err);
  }

  // Otherwise, create new ones
  const halfWidth = Math.floor(screen.availWidth / 2);

  const left = await chrome.windows.create({
    url: primary === "contact" ? contactURL : propertyURL,
    left: 0,
    top: 0,
    width: halfWidth,
    height: screen.availHeight,
    focused: true
  });

  const right = await chrome.windows.create({
    url: secondary === "property" ? propertyURL : contactURL,
    left: halfWidth,
    top: 0,
    width: halfWidth,
    height: screen.availHeight,
    focused: false
  });

  splitWindows = { left, right };
  chrome.action.setBadgeText({ text: "S" });
  chrome.action.setBadgeBackgroundColor({ color: "#00c853" });
  console.log("🪟 Split windows active:", splitWindows);
}

// --- Cleanup ---
chrome.windows.onRemoved.addListener((id) => {
  if (splitWindows.left?.id === id || splitWindows.right?.id === id) {
    splitWindows = { left: null, right: null };
    chrome.action.setBadgeText({ text: "" });
    console.log("❌ Split windows closed, reset complete");
  }
});

// --- Helper: ensure content.js is injected before messaging ---
async function ensureContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
    console.log(`🧩 Injected content.js into tab ${tabId}`);
  } catch (e) {
    console.warn("⚠️ Could not inject content script:", e.message);
  }
}
