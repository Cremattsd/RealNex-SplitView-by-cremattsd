// Matty’s Blackout – v9.1 (Full Master Toggle + Split Indicator + Safe Connect)
document.addEventListener("DOMContentLoaded", () => {
  const toggles = [
    "themeMaster",
    "lightMode",
    "darkMode",
    "splitViewToggle",
    "contactToPropertyToggle",
    "propertyToContactToggle"
  ];

  // Load saved states
  chrome.storage.local.get(toggles, (res) => {
    toggles.forEach(id => {
      const el = document.getElementById(id);
      if (el && res[id] !== undefined) el.checked = res[id];
    });

    // UI state
    if (res.darkMode) document.body.classList.add("dark-mode");
    else document.body.classList.remove("dark-mode");

    if (res.splitViewToggle)
      document.getElementById("splitIndicator").classList.add("split-active");
  });

  // Master Theme Toggle
  document.getElementById("themeMaster").addEventListener("change", (e) => {
    const enabled = e.target.checked;
    chrome.storage.local.set({ themeMaster: enabled });

    if (!enabled) {
      chrome.storage.local.set({ lightMode: false, darkMode: false });
      safeSendToContent("resetMode", true);
      document.getElementById("lightMode").checked = false;
      document.getElementById("darkMode").checked = false;
      document.body.classList.remove("dark-mode");
    }
  });

  // Light Mode
  document.getElementById("lightMode").addEventListener("change", (e) => {
    const val = e.target.checked;
    const masterOn = document.getElementById("themeMaster").checked;
    if (!masterOn) return;

    if (val) {
      document.getElementById("darkMode").checked = false;
      chrome.storage.local.set({ lightMode: true, darkMode: false });
      document.body.classList.remove("dark-mode");
      safeSendToContent("lightMode", true);
      safeSendToContent("darkMode", false);
    } else {
      chrome.storage.local.set({ lightMode: false });
      safeSendToContent("resetMode", true);
    }
  });

  // Dark Mode
  document.getElementById("darkMode").addEventListener("change", (e) => {
    const val = e.target.checked;
    const masterOn = document.getElementById("themeMaster").checked;
    if (!masterOn) return;

    if (val) {
      document.getElementById("lightMode").checked = false;
      chrome.storage.local.set({ darkMode: true, lightMode: false });
      document.body.classList.add("dark-mode");
      safeSendToContent("darkMode", true);
      safeSendToContent("lightMode", false);
    } else {
      chrome.storage.local.set({ darkMode: false });
      safeSendToContent("resetMode", true);
    }
  });

  // Split View & Relationship Toggles
  ["splitViewToggle", "contactToPropertyToggle", "propertyToContactToggle"].forEach(id => {
    const el = document.getElementById(id);
    el.addEventListener("change", () => {
      const val = el.checked;
      chrome.storage.local.set({ [id]: val });

      if (id === "contactToPropertyToggle" && val)
        chrome.storage.local.set({ propertyToContactToggle: false });
      if (id === "propertyToContactToggle" && val)
        chrome.storage.local.set({ contactToPropertyToggle: false });

      safeSendToContent(id, val);

      if (id === "splitViewToggle") {
        const indicator = document.getElementById("splitIndicator");
        indicator.classList.toggle("split-active", val);
        chrome.action.setBadgeText({ text: val ? "S" : "" });
        chrome.action.setBadgeBackgroundColor({ color: "#00c853" });
      }
    });
  });
});

// 🔒 Safe message sender with fallback injection
async function safeSendToContent(action, state) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    const url = tab.url || "";

    if (url.startsWith("chrome://") || url.startsWith("edge://") || url.startsWith("about:"))
      return;

    // Try sending message first
    await chrome.tabs.sendMessage(tab.id, { action, state });
    console.log(`✅ Sent '${action}' to content script`);
  } catch (err) {
    console.warn("⚠️ No receiver detected, injecting content.js...");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      // Retry
      await chrome.tabs.sendMessage(tab.id, { action, state });
      console.log(`🔄 Re-sent '${action}' after injecting content.js`);
    } catch (innerErr) {
      console.error("❌ Failed even after injection:", innerErr.message);
    }
  }
}
