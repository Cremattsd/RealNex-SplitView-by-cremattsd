// ===========================================
// Matty’s Blackout – v17.0 (GOD MODE EDITION)  // <— UPGRADED VERSION BABY
// TRUE White/Black Headers + FULL Gradient Killer
// Apple-8px + Subtabs + No-Icon Toolbar
// Apple-style row dividers + Grid polish
// Apple-style Tooltips + Animated Orange Hover
// + TOP-RIGHT ALIGNMENT FIX + MAP FREEZE KILLER  // <— NEW HOTNESS
// ===========================================

const ORANGE_SHADES = [
  '#f7931e','#ee7600','#f58025','#ff8800','#f57c00','#f45000','#f15929'
];
const GRAY_SHADES = ['#333333','#757575'];
let darkMode = false;

// Load saved mode
chrome.storage.local.get("darkMode", r => {
  darkMode = !!r.darkMode;
  applyTheme();
});

// Listen for popup messages
window.addEventListener("message", e => {
  const { action, state } = e.data || {};
  if (!action) return;

  if (action === "darkMode") darkMode = state;
  if (action === "lightMode") darkMode = false;
  if (action === "resetMode") darkMode = false;

  chrome.storage.local.set({ darkMode });
  applyTheme();
});

// SMART OBSERVER – Only re-theme when big changes happen (not map spam)  // <— FIX FOR MAP FREEZING 🔥
let themeTimeout = null;
const smartObserver = new MutationObserver((mutations) => {
  if (themeTimeout) return; // already scheduled

  // Ignore insane map mutations
  const isMapSpam = mutations.some(m => 
    m.addedNodes.length > 50 || 
    [...m.addedNodes].some(node => node.classList?.contains('leaflet'))
  );
  if (isMapSpam) return;

  themeTimeout = setTimeout(() => {
    requestAnimationFrame(applyTheme);
    themeTimeout = null;
  }, 150); // batch changes
});

smartObserver.observe(document.body, { 
  childList: true, 
  subtree: true, 
  attributes: true, 
  attributeFilter: ['class', 'style'] 
});


// ===========================================
// MAIN THEME ENGINE
// ===========================================
function applyTheme() {

  const textPrimary   = darkMode ? "#ffffff" : "#000000";
  const textSecondary = darkMode ? "#dddddd" : "#333333";
  const bgPrimary     = darkMode ? "#0f0f0f" : "#ffffff";
  const borderColor   = darkMode ? "#555555" : "#e6e6e6";

  document.body.style.backgroundColor = bgPrimary;
  document.body.style.color = textSecondary;

  // UNIVERSAL SWEEP
  document.querySelectorAll("*").forEach(el => {
    const s = getComputedStyle(el);
    const rawColor  = s.color.toLowerCase();
    const rawBg     = s.backgroundColor.toLowerCase();
    const rawBorder = s.borderColor.toLowerCase();

    ORANGE_SHADES.forEach(hex => {
      const rgb = hexToRgb(hex);

      if (rawColor.includes(hex.slice(1)) || rawColor.includes(rgb))
        el.style.setProperty("color", textPrimary, "important");

      if (rawBg.includes(hex.slice(1)) || rawBg.includes(rgb))
        el.style.setProperty("background-color", bgPrimary, "important");

      if (rawBorder.includes(hex.slice(1)) || rawBorder.includes(rgb))
        el.style.setProperty("border-color", borderColor, "important");
    });

    GRAY_SHADES.forEach(gray => {
      const rgb = hexToRgb(gray);
      if (rawColor.includes(gray.slice(1)) || rawColor.includes(rgb))
        el.style.setProperty("color", textPrimary, "important");
    });

    if (darkMode) {
      el.style.setProperty("color", textPrimary, "important");
      if (rawBg === "rgb(255, 255, 255)")
        el.style.setProperty("background-color", bgPrimary, "important");
    } else {
      el.style.setProperty("color", textSecondary, "important");
    }
  });

  // ===========================================
  // 🔥 FULL GRADIENT KILLER
  // ===========================================
  document.querySelectorAll("*").forEach(el => {
    const cs = getComputedStyle(el);
    const bgImg = cs.backgroundImage.toLowerCase();
    const bgRaw = cs.background.toLowerCase();

    if (
      bgImg.includes("gradient") ||
      bgRaw.includes("gradient") ||
      bgImg.includes("f9f6f1") ||
      bgImg.includes("f2efea") ||
      bgRaw.includes("f9f6f1") ||
      bgRaw.includes("f2efea")
    ) {
      const clean = darkMode ? "#0f0f0f" : "#ffffff";
      el.style.setProperty("background", clean, "important");
      el.style.setProperty("background-color", clean, "important");
      el.style.setProperty("background-image", "none", "important");
      el.style.setProperty("filter", "none", "important");
      el.style.setProperty("-ms-filter", "none", "important");
    }
  });

  // LINKS
  document.querySelectorAll(
    "a, .contact-phone, .contact-email, .contact-address, .text-elipsis, .contact-info, .value"
  ).forEach(el => {
    if (containsOrange(getComputedStyle(el).color))
      el.style.setProperty("color", textPrimary, "important");
  });

  // ORANGE SUBTEXT
  document.querySelectorAll(`
    span.position, .contact-position, .contact-title,
    .contact-company, .contact-role, .text-elipsis,
    .span80, span[style*='color: orange']
  `).forEach(el => {
    const raw = getComputedStyle(el).color.toLowerCase();
    if (containsOrange(raw)) {
      el.style.setProperty("color", textPrimary, "important");
      el.style.setProperty("font-weight", "600", "important");
    }
  });

  // LABELS
  document.querySelectorAll(`
    label, .label, .badge, .tag,
    .input-group-addon, .form-label, .pill-bg
  `).forEach(el => {
    el.style.setProperty("border-radius", "8px", "important");
  });

  // MODALS
  document.querySelectorAll("div.modal-header").forEach(el => {
    el.style.setProperty("background-color", bgPrimary, "important");
    el.style.setProperty("border-bottom", `1px solid ${borderColor}`, "important");
  });

  // BUTTONS
  document.querySelectorAll(".btn.btn-primary, .toggle-on").forEach(el => {
    el.style.setProperty("background-color", bgPrimary, "important");
    el.style.setProperty("color", textPrimary, "important");
  });

  applyImageRounding();

  // ===========================================
  // ⭐ LIST HEADERS
  // ===========================================
  document.querySelectorAll(`
    .items-list-header,
    .items-list-header *,
    .items-list-header.hide-on-dashboard,
    div.items-list-header,
    div.items-list-header *,
    .list-header-buttons,
    .list-header-buttons *,
    .extra_body_block,
    .extra_body_block *,
    .footer_notes_block,
    .footer_notes_block *
  `).forEach(el => {
    const bg  = darkMode ? "#0f0f0f" : "#ffffff";
    const txt = darkMode ? "#ffffff" : "#000000";

    el.style.setProperty("background-color", bg, "important");
    el.style.setProperty("background-image", "none", "important");
    el.style.setProperty("color", txt, "important");
    el.style.setProperty("box-shadow", "none", "important");
    el.style.setProperty("border", "1px solid " + bg, "important");
    el.style.setProperty("border-bottom", "none", "important");
  });

  // ===========================================
  // ⭐ Apple-style row separators
  // ===========================================
  document.querySelectorAll("tr, .data-row").forEach(el => {
    const div = darkMode ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)";
    el.style.setProperty("border-bottom", `1px solid ${div}`, "important");
  });

  // Grid card spacing
  document.querySelectorAll(".rn-card, .contact-card, .grid-card").forEach(el => {
    el.style.setProperty("margin-bottom", "12px", "important");
  });

  // TOOLTIP FIX
  document.querySelectorAll(".tooltip, .tooltip-inner").forEach(tt => {
    const bg  = darkMode ? "#000000" : "#ffffff";
    const txt = darkMode ? "#ffffff" : "#000000";
    const br  = darkMode ? "#444444" : "#cccccc";

    tt.style.setProperty("background", bg, "important");
    tt.style.setProperty("background-color", bg, "important");
    tt.style.setProperty("color", txt, "important");
    tt.style.setProperty("border", `1px solid ${br}`, "important");
    tt.style.setProperty("border-radius", "6px", "important");
    tt.style.setProperty("padding", "6px 10px", "important");
    tt.style.setProperty("font-size", "12px", "important");
    tt.style.setProperty("line-height", "14px", "important");
    tt.style.setProperty("box-shadow", "0px 4px 10px rgba(0,0,0,0.15)", "important");
  });

  document.querySelectorAll(".tooltip-arrow").forEach(arrow => {
    const bg = darkMode ? "#000000" : "#ffffff";
    arrow.style.setProperty("border-top-color", bg, "important");
    arrow.style.setProperty("border-bottom-color", bg, "important");
  });

  // SUBTABS
  document.querySelectorAll(`
    .header_nav_block,
    .header_nav_block *,
    .header_nav_block .tabs,
    .header_nav_block .contact-subtab
  `).forEach(el => {
    el.style.setProperty("background-color", bgPrimary, "important");
    el.style.setProperty("color", textPrimary, "important");
    el.style.setProperty("border", "none", "important");
    el.style.setProperty("box-shadow", "none", "important");
  });

  // ===========================================
  // ⭐ CARETS + HOVER ANIMATION (NEW v16.8.0)
  // ===========================================
  document.querySelectorAll(".caret, span.caret, .nav-item .caret").forEach(c => {
    const caretColor = darkMode ? "#bbbbbb" : "#999999";
    c.style.setProperty("border-top-color", caretColor, "important");
    c.style.setProperty("border-bottom-color", caretColor, "important");
    c.style.setProperty("opacity", "0.8", "important");
  });

  document.querySelectorAll("tr, .item_block, .data-row").forEach(row => {
    row.style.setProperty("transition", "background-color 0.18s ease", "important");
    row.addEventListener("mouseenter", () => {
      row.style.setProperty(
        "background-color",
        darkMode ? "rgba(255,140,0,0.25)" : "rgba(255,140,0,0.10)",
        "important"
      );
    });
    row.addEventListener("mouseleave", () => {
      row.style.setProperty(
        "background-color",
        darkMode ? "#0f0f0f" : "#ffffff",
        "important"
      );
    });
  });

  cleanTopNav();
  fixTopRightHolyAlignment();  // <— NEW CALL TO ALIGNMENT FIX 🚀
}


// ===========================================
// IMAGE ROUNDING (Apple-8px)
// ===========================================
function applyImageRounding() {
  document.querySelectorAll(`
    .avatar, img.avatar,
    img[style*="border-radius: 50%"],
    [class*="avatar"], [class*="profile-img"]
  `).forEach(el => {
    el.style.setProperty("border-radius", "8px", "important");
    el.style.setProperty("overflow", "hidden", "important");
  });

  document.querySelectorAll(`
    img, img.avatar, img.profile-pic,
    img[alt='Avatar'], .profile-image, .contact-image,
    .company-image, .property-img, .property-image,
    .listing-image, .gallery-image, .photo-wrapper img,
    .rn-avatar img, .rn-card img
  `).forEach(el => {
    el.style.setProperty("border-radius", "8px", "important");
    el.style.setProperty("object-fit", "cover", "important");
    el.style.setProperty("object-position", "center", "important");
    el.style.setProperty("overflow", "hidden", "important");
  });

  document.querySelectorAll(`
    .swiper-slide, .swiper-slide-active,
    .swiper-slide.bg-img, .swiper-slide-active.bg-img
  `).forEach(el => {
    el.style.setProperty("border-radius", "8px", "important");
    el.style.setProperty("overflow", "hidden", "important");
    el.style.setProperty("background-size", "cover", "important");
    el.style.setProperty("background-position", "center", "important");
  });
}


// ===========================================
// TOP NAV CLEANER
// ===========================================
function cleanTopNav() {

  const navWrap = document.querySelector(".main-toolbar, ul.d-flex.main-toolbar");
  if (navWrap) {
    navWrap.style.setProperty("background", "transparent", "important");
    navWrap.style.setProperty("border", "none", "important");
    navWrap.style.setProperty("box-shadow", "none", "important");
    navWrap.style.setProperty("padding-top", "4px", "important");
    navWrap.style.setProperty("padding-bottom", "2px", "important");
  }

  // REMOVE GRAY BOXES / BORDERS
  document.querySelectorAll(`
    .admin-nav--tabs ul li,
    .main-toolbar .nav-item
  `).forEach(el => {
    el.style.setProperty("border", "none", "important");
    el.style.setProperty("border-left", "none", "important");
    el.style.setProperty("background", "transparent", "important");
    el.style.setProperty("box-shadow", "none", "important");
    el.style.setProperty("min-width", "auto", "important");
    el.style.setProperty("padding", "0 4px", "important");
  });

  // REMOVE ALL ICONS
  document.querySelectorAll(`
    .main-toolbar .nav-item i,
    .main-toolbar .nav-item svg,
    .main-toolbar .nav-item img,
    .main-toolbar .nav-item .material-symbols-rounded,
    .admin-nav--tabs ul li img,
    .admin-nav--tabs ul li svg,
    .admin-nav--tabs ul li i
  `).forEach(el => {
    el.style.setProperty("display", "none", "important");
    el.style.setProperty("visibility", "hidden", "important");
    el.style.setProperty("width", "0", "important");
    el.style.setProperty("height", "0", "important");
  });

  // LABELS ONLY
  document.querySelectorAll(`
    .main-toolbar .nav-item span,
    .main-toolbar .nav-item .nav-item--caption,
    .admin-nav--tabs ul li span
  `).forEach(label => {
    label.style.setProperty("font-size", "13px", "important");
    label.style.setProperty("font-weight", "500", "important");
    label.style.setProperty("padding", "0 12px", "important");
    label.style.setProperty("line-height", "26px", "important");
    label.style.setProperty("margin", "0 auto", "important");
    label.style.setProperty("display", "block", "important");
    label.style.setProperty("text-align", "center", "important");
    label.style.setProperty("color", darkMode ? "#ffffff" : "#000000", "important");
  });

  // ACTIVE TAB UNDERLINE
  document.querySelectorAll(".main-toolbar .nav-item.active").forEach(item => {
    item.style.setProperty("border-bottom", "2px solid #f7931e", "important");
    item.style.setProperty("padding-bottom", "2px", "important");
  });
}


// ===========================================
// ULTIMATE TOP BAR ALIGNMENT + ICON PURGE v2  // <— NEW FUNCTION TO FIX YOUR TOP-RIGHT MESS
// Makes Tools / My Account / GuideMe etc. sit flush with Dashboard tabs
// ===========================================
function fixTopRightHolyAlignment() {
  // The entire top header bar
  const header = document.querySelector('.header-bar, .main-header, [class*="header"]');
  if (header) {
    header.style.setProperty('padding-top', '0px', 'important');
    header.style.setProperty('padding-bottom', '0px', 'important');
    header.style.setProperty('min-height', '70px', 'important');
    header.style.setProperty('align-items', 'flex-start', 'important');
  }

  // Push EVERYTHING to the very top – no more coward spacing
  const topRow = document.querySelector('.header-bar > div, .d-flex.justify-content-between');
  if (topRow) {
    topRow.style.setProperty('margin-top', '8px', 'important'); // tiny breathing room
    topRow.style.setProperty('gap', '20px', 'important');
  }

  // The right-side gang: Tools, Settings, My Account, GuideMe, etc.
  document.querySelectorAll('.header-right, .user-menu, .nav.navbar-nav.navbar-right, .ml-auto').forEach(el => {
    el.style.setProperty('margin-top', '0px', 'important');
    el.style.setProperty('padding-top', '0px', 'important');
    el.style.setProperty('align-self', 'flex-start', 'important');
  });

  // Make the dropdown menus (Tools ▼, My Account ▼) look identical to Dashboard tabs
  document.querySelectorAll('.navbar-right > li > a, .header-right a, .user-menu a').forEach(link => {
    link.style.setProperty('color', darkMode ? '#ffffff' : '#000000', 'important');
    link.style.setProperty('font-size', '15px', 'important');
    link.style.setProperty('font-weight', '500', 'important');
    link.style.setProperty('padding', '12px 16px', 'important');
    link.style.setProperty('border-radius', '8px', 'important');
    link.style.setProperty('transition', 'all 0.2s ease', 'important');
    link.style.setProperty('margin', '0 4px', 'important');
  });

  // Hover effect – same as main tabs
  document.querySelectorAll('.navbar-right > li > a:hover, .header-right a:hover').forEach(link => {
    link.style.setProperty('background', darkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)', 'important');
  });

  // ACTIVE STATE ORANGE UNDERLINE FOR ALL TABS (including top-right)
  const activeLinks = document.querySelectorAll('.navbar-right > li.active > a, a[aria-expanded="true"]');
  activeLinks.forEach(link => {
    link.style.setProperty('border-bottom', '3px solid #f7931e', 'important');
    link.style.setProperty('padding-bottom', '9px', 'important');
  });

  // NUKE ALL ICONS IN TOP-RIGHT (except GuideMe if you want to keep the book)
  document.querySelectorAll(`
    .navbar-right i, 
    .navbar-right svg, 
    .header-right i, 
    .header-right svg,
    .user-menu i,
    .user-menu svg
  `).forEach(icon => {
    if (!icon.closest('.guide-me')) { // spare the sacred GuideMe book
      icon.style.display = 'none !important';
    }
  });
}

// ===========================================
// Matty’s Universal Nav Icon Polish (CSS Injection)
// Apple Style + Orange Hover
// ===========================================
(function injectNavIconCSS() {
  const css = `
    .nav-item--icon,
    .nav-item--icon.material-symbols-rounded,
    nav .material-symbols-rounded,
    .menu .material-symbols-rounded {
      display: inline-flex !important;
      justify-content: center !important;
      align-items: center !important;
      width: 28px !important;
      height: 28px !important;
      border-radius: 8px !important;
      background: rgba(255,255,255,0.85) !important;
      border: 1px solid #e8e8e8 !important;
      font-size: 18px !important;
      color: #333 !important;
      font-variation-settings: 'wght' 450, 'opsz' 24 !important;
      box-shadow: 0 1px 2px rgba(0,0,0,0.08) !important;
      transition: all 0.20s ease, transform 0.12s ease !important;
      opacity: 0.9 !important;
    }

    .nav-item--icon i {
      font-size: 16px !important;
      color: #333 !important;
      opacity: 0.9 !important;
      transition: opacity 0.20s ease !important;
    }

    .nav-item--icon:hover,
    nav .material-symbols-rounded:hover,
    .menu .material-symbols-rounded:hover {
      background: linear-gradient(135deg, #f7931e, #ee7600, #f15929) !important;
      border-color: #f15929 !important;
      color: #fff !important;
      opacity: 1 !important;
      transform: translateY(-1px) !important;
    }

    .nav-item--icon:hover i {
      color: #ffffff !important;
      opacity: 1 !important;
    }
  `;

  const style = document.createElement("style");
  style.setAttribute("id", "matty-nav-icon-style");
  style.innerHTML = css;
  document.head.appendChild(style);
})();

// ===========================================
// HELPERS
// ===========================================
function containsOrange(val) {
  if (!val) return false;
  return ORANGE_SHADES.some(hex => val.toLowerCase().includes(hex.slice(1)));
}

function hexToRgb(hex) {
  const b = parseInt(hex.slice(1), 16);
  return `rgb(${(b>>16)&255}, ${(b>>8)&255}, ${b&255})`;
}